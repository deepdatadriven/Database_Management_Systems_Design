package team.hr.domain;

public class Room {
	private Integer hotelId;
	private Integer roomNo;
	private String rtype;
	private Integer price;
	private Integer floor;
	private Integer capacity;
	private String description;
	public Room(Integer hotelId, Integer roomNo, String rtype, Integer price, Integer floor, Integer capacity,
			String description) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.rtype = rtype;
		this.price = price;
		this.floor = floor;
		this.capacity = capacity;
		this.description = description;
	}
	public Room(Integer hotelId, Integer roomNo, String rtype, Integer price, Integer floor, Integer capacity) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.rtype = rtype;
		this.price = price;
		this.floor = floor;
		this.capacity = capacity;
	}
	public Room(Integer hotelId, Integer roomNo, String rtype, Integer price, Integer floor) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.rtype = rtype;
		this.price = price;
		this.floor = floor;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getFloor() {
		return floor;
	}
	public void setFloor(Integer floor) {
		this.floor = floor;
	}
	public Integer getCapacity() {
		return capacity;
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
