package team.hr.domain;

public class Breakfast {
	private Integer hotelId;
	private String type;
	private Integer price;
	private String description;
	public Breakfast(Integer hotelId, String type, Integer price, String description) {
		super();
		this.hotelId = hotelId;
		this.type = type;
		this.price = price;
		this.description = description;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
