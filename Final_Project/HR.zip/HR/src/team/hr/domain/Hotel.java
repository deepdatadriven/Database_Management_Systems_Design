package team.hr.domain;

import java.util.List;

public class Hotel {
	private Integer hotelId;
	private String stree;
	private String country;
	private String state;
	private String zip;
	private String name;
	private List<String> rtype;
	private List<String> btype;
	private List<String> stype;
	public List<String> getRtype() {
		return rtype;
	}
	public void setRtype(List<String> rtype) {
		this.rtype = rtype;
	}
	public List<String> getBtype() {
		return btype;
	}
	public void setBtype(List<String> btype) {
		this.btype = btype;
	}
	public List<String> getStype() {
		return stype;
	}
	public void setStype(List<String> stype) {
		this.stype = stype;
	}
	public Hotel(){
		
	}
	public Hotel(Integer hotelId, String stree, String country, String state, String zip, String name) {
		super();
		this.hotelId = hotelId;
		this.stree = stree;
		this.country = country;
		this.state = state;
		this.zip = zip;
		this.name = name;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getStree() {
		return stree;
	}
	public void setStree(String stree) {
		this.stree = stree;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip;
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
