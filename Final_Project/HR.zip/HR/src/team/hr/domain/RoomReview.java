package team.hr.domain;

import java.sql.Date;

public class RoomReview {
	private Integer rid;
	private double rating;
	private String text;
	private Integer cid;
	private Integer hotelId;
	private Integer roomNo;
	private Date rDate;
	public RoomReview( double rating, String text, Integer cid, Integer hotelId, Integer roomNo,
			Date rDate) {
		super();
		this.rating = rating;
		this.text = text;
		this.cid = cid;
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.rDate = rDate;
	}
	public RoomReview(double rating, String text, Integer cid, Integer hotelId, Integer roomNo) {
		super();
		this.rating = rating;
		this.text = text;
		this.cid = cid;
		this.hotelId = hotelId;
		this.roomNo = roomNo;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public Date getrDate() {
		return rDate;
	}
	public void setrDate(Date rDate) {
		this.rDate = rDate;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
}
