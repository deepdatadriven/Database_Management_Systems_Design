package team.hr.domain;

public class Customer {
	private Integer cId;
	private String name;
	private String address;
	private String phone;
	private String email;
	private String password;
	public Customer(){
		
	}
	public Customer(Integer cId, String name, String address, String phone, String email, String password) {
		super();
		this.cId = cId;
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.password = password;
	}
	public Customer(String name, String address, String phone, String email, String password) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.email = email;
		this.password = password;
	}
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
