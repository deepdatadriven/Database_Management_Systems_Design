package team.hr.domain;

import java.sql.Date;

public class BreakfastReview {
	private Integer rid;
	private Integer hotelId;
	private String btype;
	private Integer cid;
	private String text;
	private double rating;
	private Date rdate;
	public BreakfastReview( Integer hotelId, String btype, Integer cid, String text, double rating,
			Date rdate) {
		super();
		this.hotelId = hotelId;
		this.btype = btype;
		this.cid = cid;
		this.text = text;
		this.rating = rating;
		this.rdate = rdate;
	}
	public BreakfastReview(Integer hotelId, String btype, Integer cid, String text, double rating) {
		super();
		this.hotelId = hotelId;
		this.btype = btype;
		this.cid = cid;
		this.text = text;
		this.rating = rating;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getBtype() {
		return btype;
	}
	public void setBtype(String btype) {
		this.btype = btype;
	}
	public Integer getCid() {
		return cid;
	}
	public void setCid(Integer cid) {
		this.cid = cid;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public Date getRdate() {
		return rdate;
	}
	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}
}
