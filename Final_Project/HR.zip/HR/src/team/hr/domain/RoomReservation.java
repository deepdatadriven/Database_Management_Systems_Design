package team.hr.domain;

import java.sql.Date;
import java.util.List;

public class RoomReservation {
	private String Name;
	private Integer hotelId;
	private Integer roomNo;
	private Date inDate;
	private Date outDate;
	private String rtype;
	private List<String> btype;
	private List<String> stype;
	private Integer rprice;
	private Integer bprice;
	private Integer sprice;
	private double discount;
	private List<Integer> bamount;
	private Integer capacity;
	private long amount;
	private long days;
	public RoomReservation(){
		
	}
	public RoomReservation(String name, Integer hotelId, Integer roomNo, Date inDate, Date outDate, String rtype,
			List<String> btype, List<String> stype, List<Integer> bamount) {
		super();
		Name = name;
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.inDate = inDate;
		this.outDate = outDate;
		this.rtype = rtype;
		this.btype = btype;
		this.stype = stype;
		this.bamount = bamount;
	}
	public RoomReservation(String name, Integer hotelId, Integer roomNo, Date inDate, Date outDate, String rtype,
			List<String> btype, List<String> stype, Integer rprice, Integer bprice, Integer sprice, double discount,
			List<Integer> bamount, Integer capacity, long amount, long days) {
		super();
		Name = name;
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.inDate = inDate;
		this.outDate = outDate;
		this.rtype = rtype;
		this.btype = btype;
		this.stype = stype;
		this.rprice = rprice;
		this.bprice = bprice;
		this.sprice = sprice;
		this.discount = discount;
		this.bamount = bamount;
		this.capacity = capacity;
		this.amount = amount;
		this.days = days;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public Date getInDate() {
		return inDate;
	}
	public void setInDate(Date inDate) {
		this.inDate = inDate;
	}
	public Date getOutDate() {
		return outDate;
	}
	public void setOutDate(Date outDate) {
		this.outDate = outDate;
	}
	public String getRtype() {
		return rtype;
	}
	public void setRtype(String rtype) {
		this.rtype = rtype;
	}
	public List<String> getBtype() {
		return btype;
	}
	public void setBtype(List<String> btype) {
		this.btype = btype;
	}
	public List<String> getStype() {
		return stype;
	}
	public void setStype(List<String> stype) {
		this.stype = stype;
	}
	public Integer getRprice() {
		return rprice;
	}
	public void setRprice(Integer rprice) {
		this.rprice = rprice;
	}
	public Integer getBprice() {
		return bprice;
	}
	public void setBprice(Integer bprice) {
		this.bprice = bprice;
	}
	public Integer getSprice() {
		return sprice;
	}
	public void setSprice(Integer sprice) {
		this.sprice = sprice;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public List<Integer> getBamount() {
		return bamount;
	}
	public void setBamount(List<Integer> bamount) {
		this.bamount = bamount;
	}
	public Integer getCapacity() {
		return capacity;
	}
	public void setCapacity(Integer capacity) {
		this.capacity = capacity;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public long getDays() {
		return days;
	}
	public void setDays(long days) {
		this.days = days;
	}

}
