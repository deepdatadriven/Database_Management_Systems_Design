package team.hr.domain;

import java.sql.Date;

public class CreditCard {
	private String number;
	private String type;
	private String baddress;
	private Integer code;
	private Date expDate;
	private String name;
	private Integer cId;
	public CreditCard(String number, String type, String address, Integer code, Date expDate, String name,
			Integer cId) {
		super();
		this.number = number;
		this.type = type;
		this.baddress = address;
		this.code = code;
		this.expDate = expDate;
		this.name = name;
		this.cId = cId;
	}
	public CreditCard(String number, String type, String address, Integer code, Date expDate, String name) {
		super();
		this.number = number;
		this.type = type;
		this.baddress = address;
		this.code = code;
		this.expDate = expDate;
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getBaddress() {
		return baddress;
	}
	public void setBaddress(String address) {
		this.baddress = address;
	}
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public Date getExpDate() {
		return expDate;
	}
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
}
