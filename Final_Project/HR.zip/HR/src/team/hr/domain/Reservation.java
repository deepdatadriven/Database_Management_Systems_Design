package team.hr.domain;

import java.sql.Date;
import java.util.List;

public class Reservation {
	private String invoiceNo;
	private Integer cId;
	private String cNumber;
	private Date rDate;
	private Integer amount;
	private long days;
	private List<RoomReservation> rooms;
	public Reservation(){
		
	}
	public Reservation(String invoiceNo, Integer cId, String cNumber, Date rDate, Integer amount) {
		super();
		this.invoiceNo = invoiceNo;
		this.cId = cId;
		this.cNumber = cNumber;
		this.rDate = rDate;
		this.amount = amount;
	}
	public String getInvoiceNo() {
		return invoiceNo;
	}
	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	public String getcNumber() {
		return cNumber;
	}
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}
	public Date getrDate() {
		return rDate;
	}
	public void setrDate(Date rDate) {
		this.rDate = rDate;
	}
	public Integer getAmount() {
		return amount;
	}
	public void setAmount(Integer amount) {
		this.amount = amount;
	}
	public long getDays() {
		return days;
	}
	public void setDays(long days) {
		this.days = days;
	}
	public List<RoomReservation> getRooms() {
		return rooms;
	}
	public void setRooms(List<RoomReservation> rooms) {
		this.rooms = rooms;
	}
	
}
