package team.hr.domain;

import java.sql.Date;

public class ServiceReview {
	private Integer rid;
	private Integer hotelId;
	private String stype;
	private Integer cId;
	private double rating;
	private String text;
	private Date rdate;
	public ServiceReview(Integer hotelId, String stype, Integer cId, double rating, String text,
			Date rdate) {
		super();
		this.hotelId = hotelId;
		this.stype = stype;
		this.cId = cId;
		this.rating = rating;
		this.text = text;
		this.rdate = rdate;
	}
	public ServiceReview(Integer hotelId, String stype, Integer cId, double rating, String text) {
		super();
		this.hotelId = hotelId;
		this.stype = stype;
		this.cId = cId;
		this.rating = rating;
		this.text = text;
	}
	public Integer getRid() {
		return rid;
	}
	public void setRid(Integer rid) {
		this.rid = rid;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getStype() {
		return stype;
	}
	public void setStype(String stype) {
		this.stype = stype;
	}
	public Integer getcId() {
		return cId;
	}
	public void setcId(Integer cId) {
		this.cId = cId;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Date getRdate() {
		return rdate;
	}
	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}
}
