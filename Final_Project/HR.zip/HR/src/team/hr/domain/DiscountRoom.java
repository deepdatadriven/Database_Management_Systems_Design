package team.hr.domain;

import java.sql.Date;

public class DiscountRoom {
	private Integer hotelId;
	private Integer roomNo;
	private double discount;
	private Date start;
	private Date end;
	public DiscountRoom(Integer hotelId, Integer roomNo, double discount, Date start, Date end) {
		super();
		this.hotelId = hotelId;
		this.roomNo = roomNo;
		this.discount = discount;
		this.start = start;
		this.end = end;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(Integer roomNo) {
		this.roomNo = roomNo;
	}
	public double getDiscount() {
		return discount;
	}
	public void setDiscount(double discount) {
		this.discount = discount;
	}
	public Date getStart() {
		return start;
	}
	public void setStart(Date start) {
		this.start = start;
	}
	public Date getEnd() {
		return end;
	}
	public void setEnd(Date end) {
		this.end = end;
	}
}
