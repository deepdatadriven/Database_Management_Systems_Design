package team.hr.domain;

public class Service {
	private Integer hotelId;
	private String stype;
	private Integer sprice;
	public Service(Integer hotelId, String stype, Integer sprice) {
		super();
		this.hotelId = hotelId;
		this.stype = stype;
		this.sprice = sprice;
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public String getStype() {
		return stype;
	}
	public void setStype(String stype) {
		this.stype = stype;
	}
	public Integer getSprice() {
		return sprice;
	}
	public void setSprice(Integer sprice) {
		this.sprice = sprice;
	}
}
