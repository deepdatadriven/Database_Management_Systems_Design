package team.hr.domain;

public class Manager {
	private String name;
	private String password;
	private String recommendation;
	public Manager(){
		
	}
	public Manager(String name, String password, String recommendation) {
		super();
		this.name = name;
		this.password = password;
		this.recommendation = recommendation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getRecommendation() {
		return recommendation;
	}
	public void setRecommendation(String recommendation) {
		this.recommendation = recommendation;
	}
}
