package team.hr.user.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.Customer;
import team.hr.service.MyService;

/**
 * Servlet implementation class Review
 */
@WebServlet("/RoomReview")
public class RoomReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RoomReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		MyService myService = new MyService();
		String name = (String)request.getSession().getAttribute("name");
		String room = request.getParameter("room");
		String[] array = room.split(" ");
		String hotelName = array[0];
		Integer hotelId = myService.getHotelId(hotelName);
		Integer roomNo = Integer.parseInt(array[1]);
		double rating = Double.parseDouble(request.getParameter("rating"));
		String text = request.getParameter("text");
		Customer customer = myService.getCustomerInfo(name);
		Integer cid = customer.getcId();
		team.hr.domain.RoomReview roomReview = new team.hr.domain.RoomReview(rating, text, cid, hotelId, roomNo);
		myService.roomReview(roomReview);
		request.setAttribute("recommendation", myService.getRecommendation());
		request.setAttribute("roomInfo", "Add room review succeed");
		request.getRequestDispatcher("/WEB-INF/MyPage/review.jsp").forward(request, response);
	}

}
