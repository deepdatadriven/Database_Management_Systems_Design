package team.hr.user.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import team.hr.service.MyService;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		if(request.getParameter("register")!=null){
			response.sendRedirect("register.jsp");
			return;
		}
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		if(name == null || password == null || name.equals("") || password.equals("")){
			return;
		}
		MyService myService = new MyService();
		int code = myService.login(name, password);
		String page = "login.jsp";
		request.setAttribute("recommendation", myService.getRecommendation());
		switch (code) {
		case 1:
			request.setAttribute("userError", name+" Not Exist");
			break;
		case 2:
			request.setAttribute("passwordError", "Wrong Password");
			break;
		case 3:
			HttpSession session = request.getSession();
			session.setAttribute("name", name);
			page = "/WEB-INF/MyPage/customer_manage.jsp";
			session.setMaxInactiveInterval(60*60);
		}
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	}

}
