package team.hr.user.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.service.MyService;

/**
 * Servlet implementation class Review
 */
@WebServlet("/ToReview")
public class ToReview extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ToReview() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String cName = (String)request.getSession().getAttribute("name");
		;
		MyService myService = new MyService();
		List<String> rooms = myService.getOrderRoom(cName);
		
		List<String> services = myService.getOrderService(cName);
		
		List<String> breakfasts = myService.getOrderBreakfast(cName);
		
		request.getSession().setAttribute("rooms", rooms);
		request.getSession().setAttribute("services", services);
		request.getSession().setAttribute("breakfasts", breakfasts);
		request.setAttribute("recommendation", myService.getRecommendation());
		request.getRequestDispatcher("/WEB-INF/MyPage/review.jsp").forward(request, response);
	}

}
