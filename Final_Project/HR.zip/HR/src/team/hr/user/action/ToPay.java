package team.hr.user.action;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.RoomReservation;
import team.hr.service.MyService;

/**
 * Servlet implementation class Pay
 */
@WebServlet("/ToPay")
public class ToPay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ToPay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	@SuppressWarnings("unchecked")
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		List<RoomReservation> roomReservations = (List<RoomReservation>)request.getSession().getAttribute("roomReservations");
		if(roomReservations == null || roomReservations.size()==0){
			request.setAttribute("info", "There is no room be selected, please select a room");
			request.getRequestDispatcher("/WEB-INF/MyPage/reservation.jsp").forward(request, response);
		}
		MyService myService = new MyService();
		long price = 0;
		for(int i=0;i<roomReservations.size();i++){
			price+=myService.evaluatePrice(roomReservations.get(i));
		}
		request.setAttribute("price", price);
		String cName = (String) request.getSession().getAttribute("name");
		request.setAttribute("recommendation", myService.getRecommendation());
		request.setAttribute("cards", myService.getCards(cName));
		List<RoomReservation> list = (List<RoomReservation>) request.getSession().getAttribute("roomReservations");
		boolean flag = true;
		String page = "/WEB-INF/MyPage/pay.jsp";
		for(int i=0;i<list.size();i++){
			RoomReservation r1 = list.get(i);
			Date inDate1 = r1.getInDate();
			Date outDate1 = r1.getOutDate();
			for(int j=0;j<list.size();j++){
				if(j==i||r1.getHotelId()!=list.get(j).getHotelId()||r1.getRoomNo()!=list.get(j).getRoomNo()){
					continue;
				}
				RoomReservation r2 = list.get(j);
				Date inDate2 = r2.getInDate();
				Date outDate2 = r2.getOutDate();
				if(!(inDate1.getTime()>=outDate2.getTime()||outDate1.getTime()<=inDate2.getTime())){
					flag = false;
				}
			}
		}
		if(!flag){
			page = "/WEB-INF/MyPage/reservation.jsp";
			request.getSession().removeAttribute("roomReservations");
			request.setAttribute("cinfo", "Room reservation time is conflict, please do reservation again");
		}
		request.getRequestDispatcher(page).forward(request, response);
	}

}
