package team.hr.user.action;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.RoomReservation;
import team.hr.service.MyService;

/**
 * Servlet implementation class AddRoomReservation
 */
@WebServlet("/AddRoomReservation")
public class AddRoomReservation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddRoomReservation() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		try{
			MyService myService = new MyService();
			Integer hotelId = Integer.parseInt(request.getParameter("hotelId"));
			String rtype = request.getParameter("rtype");
			String[] stypes = request.getParameterValues("stype");
			List<String> stype = new ArrayList<>();
			if(stypes!=null&&!stypes.equals("")){
				for(int i=0;i<stypes.length;i++){
					stype.add(stypes[i]);
				}
			}
			String btypes = request.getParameter("btype");
			String[] parts = btypes.split(",");
			List<String> btype = new ArrayList<>();
			if(btypes!=null&&!btypes.equals("")){
				for(int i=0;i<parts.length;i++){
					String[] p = parts[i].split(":");
					btype.add(p[0]);
				}
			}
			Integer capacity = Integer.parseInt(request.getParameter("capacity"));
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date inDate = new Date((sdf.parse(request.getParameter("inDate"))).getTime());
			Date outDate = new Date((sdf.parse(request.getParameter("outDate"))).getTime());
			String bamounts = request.getParameter("bamount");
			parts = bamounts.split(" ");
			List<Integer> bamount = new ArrayList<>();
			if(bamounts!=null&&!bamounts.equals("")){
				for(int i=0;i<parts.length;i++){
					bamount.add(Integer.parseInt(parts[i]));
				}
			}
			RoomReservation roomReservation = new RoomReservation();
			roomReservation.setHotelId(hotelId);
			roomReservation.setName(myService.getHotelDetail(hotelId).getName());
			roomReservation.setRtype(rtype);
			roomReservation.setStype(stype);
			roomReservation.setBtype(btype);
			roomReservation.setInDate(inDate);
			roomReservation.setOutDate(outDate);
			roomReservation.setCapacity(capacity);
			roomReservation.setBamount(bamount);
			request.setAttribute("recommendation", myService.getRecommendation());
			Integer roomNo = myService.findARoom(roomReservation);
			java.util.Date date = new java.util.Date();
			if(outDate.getTime()<inDate.getTime()||inDate.getTime()<date.getTime()){
				request.setAttribute("info", "Reservation Time Is Illegal");
				request.getRequestDispatcher("/WEB-INF/MyPage/reservation2.jsp").forward(request, response);
			}
			else if(roomNo == 0){
				request.setAttribute("info", "This room type is currently not available or guest number is more than the room capacity");
				request.getRequestDispatcher("/WEB-INF/MyPage/reservation2.jsp").forward(request, response);
			}
			else{
				List<RoomReservation> roomReservations = (List<RoomReservation>)request.getSession().getAttribute("roomReservations");
				if(roomReservations==null){
					roomReservations = new ArrayList<>();
				}
				roomReservation.setRoomNo(roomNo);
				roomReservation.setDays((roomReservation.getOutDate().getTime()-roomReservation.getInDate().getTime())/(24*60*60*1000));
				roomReservations.add(roomReservation);
				roomReservation.setAmount(myService.evaluatePrice(roomReservation));
				request.getSession().setAttribute("roomReservations", roomReservations);
				request.setAttribute("info", "A room reservation succeed");
				request.getRequestDispatcher("./Reservation").forward(request, response);
			}
		}
		catch(Exception e){
			request.setAttribute("info", "Room reservation failed");
			request.getRequestDispatcher("/WEB-INF/MyPage/reservation2.jsp").forward(request, response);
			e.printStackTrace();
		}
		
	}
}
