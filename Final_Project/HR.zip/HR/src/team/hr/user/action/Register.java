package team.hr.user.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.Customer;
import team.hr.service.MyService;

/**
 * Servlet implementation class Register
 */
@WebServlet("/Register")
public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		if(request.getParameter("login")!=null){
			response.sendRedirect("login.jsp");
			return;
		}
		String name=request.getParameter("name");
		String password = request.getParameter("password");
		String address=request.getParameter("address");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		MyService myService = new MyService();
		String page = "login.jsp";
		request.setAttribute("recommendation", myService.getRecommendation());
		if(!myService.register(new Customer(name, address, phone, email, password))){
			request.setAttribute("userError", name+" already exist");
			page = "register.jsp";
			//request.getRequestDispatcher("/WEB-INF/MyPage/register.jsp").forward(request, response);
		}
		//else{
			//request.getRequestDispatcher("login.jsp").forward(request, response);
		///}
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	}
    

}
