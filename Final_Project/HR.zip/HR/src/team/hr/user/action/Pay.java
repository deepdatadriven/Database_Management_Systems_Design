package team.hr.user.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.RoomReservation;
import team.hr.service.MyService;

/**
 * Servlet implementation class Pay
 */
@WebServlet("/Pay")
public class Pay extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Pay() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		List<RoomReservation> list = (List<RoomReservation>) request.getSession().getAttribute("roomReservations");
		Integer amount = Integer.parseInt(request.getParameter("amount"));
		String cName = (String)request.getSession().getAttribute("name");
		String cNumber = request.getParameter("card");
		MyService myService = new MyService();
		String page = "/WEB-INF/MyPage/customer_manage.jsp";
		request.setAttribute("recommendation", myService.getRecommendation());
		myService.pay(list, amount, cName, cNumber);
		request.getSession().removeAttribute("roomReservations");
		request.getRequestDispatcher(page).forward(request, response);
	}

}
