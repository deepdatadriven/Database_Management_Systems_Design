package team.hr.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import team.hr.domain.Breakfast;
import team.hr.domain.BreakfastReview;
import team.hr.domain.CreditCard;
import team.hr.domain.Customer;
import team.hr.domain.DiscountRoom;
import team.hr.domain.Hotel;
import team.hr.domain.Manager;
import team.hr.domain.Reservation;
import team.hr.domain.Room;
import team.hr.domain.RoomReservation;
import team.hr.domain.RoomReview;
import team.hr.domain.Service;
import team.hr.domain.ServiceReview;

public class MyDao {
	private Connection connection = null;
	private ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
	public MyDao(){
		getCon1();
	}
	public Connection getCon1() {
		try {
			comboPooledDataSource.setJdbcUrl("jdbc:mysql://localhost/hr?characterEncoding=UTF-8&useSSL=false");
			comboPooledDataSource.setDriverClass("com.mysql.jdbc.Driver");
			comboPooledDataSource.setUser("root");
			comboPooledDataSource.setPassword("root");
			comboPooledDataSource.setAcquireIncrement(6);
			comboPooledDataSource.setMaxPoolSize(100);
			comboPooledDataSource.setMaxStatements(800);
			connection = comboPooledDataSource.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}
	public Connection getCon(){
		return connection;
	}
    
	private void execSQLNoRs(String sql, Object... args) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = getCon().prepareStatement(sql);
			for (int i = 0; i < args.length; i++) {
				if(args.getClass().getName().equals("java.sql.Date")){
					ps.setTimestamp(i+1, (Timestamp) args[i]);
				}
				else{
					ps.setObject(i + 1, args[i]);
				}
			}
			ps.execute();
			rs = ps.getResultSet();
			
		} catch (SQLException e) {

			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)
				rs.close();
				if(ps!=null)
				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			}
		}
	}
    
	private ResultSet execSQL(String sql, Object... args) {
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			ps = getCon().prepareStatement(sql);
			for (int i = 0; i < args.length; i++) {
				if(args.getClass().getName().equals("java.sql.Date")){
					ps.setTimestamp(i+1, (Timestamp) args[i]);
				}
				else{
					ps.setObject(i + 1, args[i]);
				}
			}
			ps.execute();
			rs = ps.getResultSet();
			
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return rs;
	}

	public void saveBreakfast(Breakfast breakfast) {
		String sql = "insert into breakfast values(?,?,?,?)";
		execSQLNoRs(sql, breakfast.getHotelId(), breakfast.getType(), breakfast.getPrice(), breakfast.getDescription());

	}

	public void saveCreditCard(CreditCard card) {
		String sql = "insert into credit_card values(?,?,?,?,?,?,?)";
		execSQLNoRs(sql, card.getNumber(), card.getType(), card.getBaddress(), card.getCode(), card.getExpDate(),
				card.getName(), card.getcId());

	}
	
	public int queryCount(String tableName){
		int result = 0;
		String sql = " select count(*) from "+tableName;
		ResultSet rs = execSQL(sql);
		try {
			if(rs.next()){
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return result;
	}
	public boolean saveCustomer(Customer customer) {
		String sql = "insert into customer values(?,?,?,?,?,?)";
		if (queryCustomer(customer.getName()) == null) {
			execSQLNoRs(sql, queryCount("customer"),customer.getName(), customer.getAddress(), customer.getPhone(), customer.getEmail(),
					customer.getPassword());
	
			return true;
		} else
			return false;
	}
	
	public boolean saveManager(Manager manager) {
		String sql = "insert into manager values(?,?,?)";
		if (queryManager1(manager.getName()) == null) {
			execSQLNoRs(sql, manager.getName(), manager.getPassword(), manager.getRecommendation());	
			return true;
		} else
			return false;
	}

	public void saveRoom(Room room) {
		String sql = "insert into room values(?,?,?,?,?,?,?)";
		execSQLNoRs(sql, room.getHotelId(), room.getRoomNo(), room.getRtype(), room.getPrice(), room.getFloor(),room.getCapacity(),room.getDescription());

	}

	public void saveService(Service service) {
		String sql = "insert into service values(?,?,?)";
		execSQLNoRs(sql, service.getHotelId(), service.getStype(), service.getSprice());
	
	}

	public void saveReservation(Reservation reservation) {
		String sql = "insert into reservation values(?,?,?,now(),?)";
		execSQLNoRs(sql, new Object[] { reservation.getInvoiceNo(), reservation.getcId(), reservation.getcNumber(), reservation.getAmount() });
	
	}

	public void saveRoomReservation(RoomReservation r, String invoiceNo) {
		String sql = "insert into room_reservation values(?,?,?,?,?)";
		execSQLNoRs(sql, new Object[] { invoiceNo, r.getHotelId(), r.getRoomNo(), r.getInDate(), r.getOutDate() });
		
	}

	public void saveRresvBreakfast(Integer hotelId,String btype,Integer roomNo,Date inDate,Integer bamount) {
		String sql = "insert into rresv_breakfast values(?,?,?,?,?)";
		execSQLNoRs(sql, hotelId,btype,roomNo,inDate,bamount);
		
	}

	public void saveRresvService(Integer hotelId,String stype,Integer roomNo,Date inDate) {
		String sql = "insert into rresv_service values(?,?,?,?)";
		execSQLNoRs(sql, hotelId,stype,roomNo,inDate);
		
	}

	public void saveRoomReview(RoomReview r) {
		String sql = "insert into room_review(rating,text,cid,hotel_id,room_no,rdate) values(?,?,?,?,?,now())";
		execSQLNoRs(sql, new Object[] { r.getRating(), r.getText(), r.getCid(), r.getHotelId(), r.getRoomNo() });
		
	}

	public void saveServiceReview(ServiceReview s) {
		String sql = "insert into service_review(hotel_id,s_type,c_id,rating,text,rdate)values(?,?,?,?,?,now())";
		execSQLNoRs(sql, new Object[] { s.getHotelId(), s.getStype(), s.getcId(), s.getRating(), s.getText() });
		
	}

	public void saveBreakfastReview(BreakfastReview b) {
		String sql = "insert into breakfast_review(hotel_id,b_type,c_id,text,rating,rdate) values(?,?,?,?,?,now())";
		execSQLNoRs(sql, new Object[] { b.getHotelId(), b.getBtype(), b.getCid(), b.getText(), b.getRating()});	
	}

	public void saveDiscountRoom(DiscountRoom r) {
		String sql = "insert into discount_room values(?,?,?,?,?)";
		execSQLNoRs(sql, r.getHotelId(), r.getRoomNo(), r.getDiscount(), r.getStart(), r.getEnd());
		
	}
	public void saveHotel(Hotel hotel){
		String sql = "insert into hotel values(?,?,?,?,?,?)";
		execSQLNoRs(sql,hotel.getHotelId(),hotel.getStree(),hotel.getCountry(),hotel.getState(),hotel.getZip(),hotel.getName());
		
	}
	
	public void savePhone(Integer hotelId,String phone){
		String sql = "insert into phone(hotel_id,phone) values(?,?)";
		execSQLNoRs(sql, hotelId,phone);
	}
	public void updateCard(String cNumber2,String cNumber1){
		String sql = "update credit_card set c_number=? where c_number=?";
		execSQLNoRs(sql,cNumber2,cNumber1);
	}
	

	public Customer queryCustomer(String name) {
		String sql = "select*from customer where name=?";
		ResultSet rs = execSQL(sql, name);
		Customer customer = null;
		try {
			while (rs.next()) {
				customer = new Customer();
				customer.setcId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setAddress(rs.getString(3));
				customer.setPhone(rs.getString(4));
				customer.setEmail(rs.getString(5));
				customer.setPassword(rs.getString(6));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return customer;
	}
	
	public Manager queryManager1(String name) {
		String sql = "select*from manager where name=?";
		ResultSet rs = execSQL(sql, name);
		Manager manager = null;
		try {
			while (rs.next()) {
				manager = new Manager();				
				manager.setName(rs.getString(1));
				manager.setPassword(rs.getString(2));
				manager.setRecommendation(rs.getString(3));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return manager;
	}

	public ResultSet queryHotel(String country, String state) {
		String sql = "select*from hotel where country=? and state=?";
		return execSQL(sql, new Object[] { country, state });
	}

	public ResultSet queryHotel(Integer hotelId) {
		String sql = "select*from hotel where hotel_id=?";
		return execSQL(sql, new Object[] { hotelId });
	}

	public ResultSet queryRoomByHotelId(Integer hotelId) {
		String sql = "select * from room where hotel_id=?";
		return execSQL(sql, new Object[] { hotelId });
	}
	
	public ResultSet queryRtypeByHotelId(Integer hotelId){
		String sql = "select distinct rtype from room where hotel_id=?";
		return execSQL(sql, new Object[] { hotelId });
	}

	public ResultSet queryBreakfast(Integer hotelId) {
		String sql = "select distinct b_type from breakfast where hotel_id=?";
		return execSQL(sql, new Object[] { hotelId });
	}

	public ResultSet queryService(Integer hotelId) {
		String sql = "select distinct s_type from service where hotel_id=?";
		return execSQL(sql, new Object[] { hotelId });
	}

	public ResultSet queryRoomByRoomNo(Integer roomNo) {
		String sql = "select* from room where room_no=?";
		return execSQL(sql, new Object[] { roomNo });
	}

	public ResultSet queryService(String stype) {
		String sql = "select* from service where s_type=?";
		return execSQL(sql, new Object[] { stype });
	}

	public ResultSet queryBreakfast(String btype) {
		String sql = "select* from breakfast where b_type=?";
		return execSQL(sql, new Object[] { btype });
	}

	public ResultSet queryCards(Integer cId) {
		String sql = "select*from credit_card where c_id=?";
		return execSQL(sql, new Object[] { cId });
	}

	public ResultSet queryReservation(String cName) {
		Customer customer = queryCustomer(cName);
		String sql = "select*from reservation where c_id=?";
		return execSQL(sql, new Object[] { customer.getcId() });
	}

	public ResultSet queryOrderRoom(String cName) {
		Customer customer = queryCustomer(cName);
		String sql = "select distinct hotel_id,room_no from reservation natural join room_reservation where c_id=?";
		return execSQL(sql, new Object[] { customer.getcId() });
	}

	public ResultSet queryOrderService(String cName) {
		Customer customer = queryCustomer(cName);
		String sql = "select hotel_id,s_type from (reservation NATURAL JOIN room_reservation)NATURAL JOIN rresv_service where c_id=?";
		return execSQL(sql, new Object[] { customer.getcId() });
	}

	public ResultSet queryOrderBreakfast(String cName) {
		Customer customer = queryCustomer(cName);
		String sql = "select distinct hotel_id,b_type from (reservation NATURAL JOIN room_reservation)NATURAL JOIN rresv_breakfast where c_id=?";
		return execSQL(sql, new Object[] { customer.getcId() });
	}

	public ResultSet queryRoomReservation(Integer roomNo,Integer hotelId) {
		String sql = "select*from room_reservation where room_no=? and hotel_id=?";
		return execSQL(sql, new Object[] { roomNo ,hotelId});
	}
	
	public ResultSet queryRoomReservationBr(String invoiceNo){
		String sql = "select*from (rresv_breakfast NATURAL JOIN room_reservation) where invoice_no=?";
		return execSQL(sql,invoiceNo);
	}
	
	public ResultSet queryRoomReservationSe(String invoiceNo){
		
		String sql = "select*from (rresv_service NATURAL JOIN room_reservation) where invoice_no=?";
		return execSQL(sql,invoiceNo);
	}

	public ResultSet queryDiscountRoom(Integer roomNo,Integer hotelId) {
		String sql = "select*from discount_room where room_no=? and hotel_id=?";
		return execSQL(sql, new Object[] { roomNo,hotelId });
	}

	public ResultSet queryHotelId(String hotelName) {
		String sql = "select hotel_id from hotel where name=?";
		return execSQL(sql, hotelName);
	}

	public ResultSet queryManager(String name) {
		String sql = "select*from manager where name=?";
		return execSQL(sql, name);
	}

	public ResultSet queryBestBreakfast(Date start,Date end) {
		String sql = "select b_type,avg(rating) from breakfast_review where (b_type,rating) in (select b_type,rating from breakfast_review where rdate BETWEEN ? and ?) GROUP BY b_type ORDER BY avg(rating) DESC";
		return execSQL(sql,start,end);
	}

	public ResultSet queryBestRoom(Date start,Date end,Integer hotelId) {
		String sql = "select hotel_id,rtype,avg(rating) from (room_review natural join room) where (rtype,rating,hotel_id) in (select rtype,rating,hotel_id from (room_review NATURAL JOIN room) where hotel_id=? and rdate BETWEEN ? and ? ) GROUP BY rtype ORDER BY avg(rating) DESC";
		return execSQL(sql,hotelId,start,end);
	}

	public ResultSet queryFiveBestCustomer(Date start,Date end) {
		String sql = "select c_Id,name,sum(amount),reservation.r_date from(customer NATURAL JOIN reservation) group by c_Id having reservation.r_date BETWEEN ? and ? order by sum(amount) desc ";
		return execSQL(sql,start,end);
	}

	public ResultSet queryBestService(Date start,Date end) {
		String sql = "select s_type,avg(rating) from service_review where (s_type,rating) in (select s_type,rating from service_review where rdate BETWEEN ? and ?) GROUP BY s_type ORDER BY avg(rating) DESC";
		return execSQL(sql,start,end);
	}

	public void updateCustomer(Customer customer) {
		String sql = "update customer set address=?,phone=?,email=?,password=? where name=?";
		execSQLNoRs(sql, new Object[] { customer.getAddress(), customer.getPhone(), customer.getEmail(),
				customer.getPassword(), customer.getName() });
	}

	public void updateRoom(Room room) {
		String sql = "update room set rtype=?,price=?,floor=? ,capacity=?,room_description=? where hotel_id=? and room_no=?";
		execSQLNoRs(sql, room.getRtype(), room.getPrice(), room.getFloor(), room.getCapacity(),room.getDescription(),room.getHotelId(), room.getRoomNo());
	}

	public void updateBreakfast(Breakfast b) {
		String sql = "update breakfast set b_price=?,description=? where hotel_id=? and b_type=?";
		execSQLNoRs(sql, b.getPrice(), b.getDescription(), b.getHotelId(), b.getType());
	}

	public void updateService(Service s) {
		String sql = "update service set s_price=? where hotel_id=? and s_type=?";
		execSQLNoRs(sql, s.getSprice(), s.getHotelId(), s.getStype());
	}
	
	public void updateRecommendation(String recommendation){
		String sql = "update manager set recommendation=?";
		execSQLNoRs(sql, recommendation);
	}
	
	public ResultSet getRecommendation(){
		String sql = "select*from manager";
		return execSQL(sql);
	}
	
	public void saveManager(String name,String password,String info){
		String sql = "insert into manager values(?,?,?)";
		execSQLNoRs(sql,name,password,info);
	}
	
	public void updateDiscountRoom(DiscountRoom discountRoom){
		String sql = "update discount_room set discount=?,start_date=?,end_date=? where hotel_id=? and room_no=?";
		execSQLNoRs(sql, discountRoom.getDiscount(),discountRoom.getStart(),discountRoom.getEnd(),discountRoom.getHotelId(),discountRoom.getRoomNo());
	}
}
