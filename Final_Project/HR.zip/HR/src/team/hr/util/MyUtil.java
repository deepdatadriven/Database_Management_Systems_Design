package team.hr.util;

import java.sql.Date;
import java.util.Calendar;
import java.util.Random;

public class MyUtil {
	public static Date getSQLDate(java.util.Date date) {
		return new Date(date.getTime());
	}

	public static String getInvoiceNo() {
		Calendar calendar = Calendar.getInstance();
		String year = calendar.get(Calendar.YEAR) + "";
		String month = calendar.get(Calendar.MONTH) + "";
		String day = calendar.get(Calendar.DAY_OF_MONTH) + "";
		String hour = calendar.get(Calendar.HOUR) + "";
		String minute = calendar.get(Calendar.MINUTE) + "";
		String second = calendar.get(Calendar.SECOND) + "";
		Random random = new Random();
		Integer r2 = random.nextInt(100000)%900 + 1007;
		Integer r1 = random.nextInt(100000)%800+2050;
		String result = minute + second + +r1+hour + month + year + day + r2;
		return result;
	}
	public static void main(String[] args) {
		Date date = new Date(34343);
		System.out.println(date.getClass().getName());
	}
}
