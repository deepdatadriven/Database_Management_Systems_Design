package team.hr.util;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import team.hr.dao.MyDao;
import team.hr.domain.Breakfast;
import team.hr.domain.BreakfastReview;
import team.hr.domain.CreditCard;
import team.hr.domain.Customer;
import team.hr.domain.DiscountRoom;
import team.hr.domain.Hotel;
import team.hr.domain.Room;
import team.hr.domain.RoomReservation;
import team.hr.domain.RoomReview;
import team.hr.domain.Service;
import team.hr.domain.ServiceReview;
import team.hr.service.MyService;

public class FillData {
	@SuppressWarnings("deprecation")
	public static void main(String...args){
		System.out.println("Population Start");
		int choose;
		Random random = new Random();
		MyDao myDao = new MyDao();
		String[] btypes = {"continental", "English", "Italian", "American", "French"};
		Integer[] bprices = {100,200,250,150,230};
		String[] bintros = {"continental", "English", "Italian", "American", "French"};
		String[] stypes = {"parking", "laundry", "airport-drop-off", "airport-pick-up"};
		Integer[] sprices = {10,13,21,21};
		String[] rtypes = {"standard", "double", "deluxe", "suite"};
		Integer[] rprices = {300,400,500,600};
		Integer[] capacity = {1,2,3,4};
		String[] cardTypes = {"Visa", "Master", "Discover", "Amex"};
		MyService myService = new MyService();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		myDao.saveManager("admin", "admin","Hulton Hotel Chain");
		for(int i=0;i<200;i++){
			//Hotel
			int zipo = 7029+i;
			Hotel hotel = new Hotel(i, "street"+i, "country"+i, "state"+i, "0"+zipo, "hotel"+i);
			myDao.saveHotel(hotel);
			//Phone
			for(int j=0;j<20;j++){
				String phone = "139"+String.valueOf(random.nextInt(8999)+1000)+String.valueOf(random.nextInt(8999)+1000);
				myDao.savePhone(i, phone);
			}
			//Breakfast
			for(choose=0;choose<5;choose++){
				Breakfast breakfast = new Breakfast(i, btypes[choose], bprices[choose], bintros[choose]);
				myDao.saveBreakfast(breakfast);
			}
			//Service
			for(choose=0;choose<4;choose++){
				Service service = new Service(i, stypes[choose], sprices[choose]);
				myDao.saveService(service);
			}
			//DiscountRoom and Room
			for(int j=1;j<11+i%3;j++){
				choose = random.nextInt(4);
				Room room = new Room(i, j, rtypes[choose], rprices[choose], j%5,capacity[choose],rtypes[choose]);
				myDao.saveRoom(room);
				choose = random.nextInt(10);
				Date start = new Date(117, choose, random.nextInt(28)+1);
				Date end = new Date(117, choose+2, random.nextInt(28)+1);
				DiscountRoom discountRoom = new DiscountRoom(i, j, 0.8+(random.nextInt(20))*0.01, start, end);
				myDao.saveDiscountRoom(discountRoom);
			}
		}
		
		for(int i=0;i<1000;i++){
			//Customer	
			Customer customer = new Customer(i,"customer"+i, "street"+i, "1562648543"+i%10, "234782"+i+"c@gmail.com", "p"+i);
			myDao.saveCustomer(customer);
			//CreditCard
			Date expDate = new Date(130, 3, 3);
			choose = random.nextInt(4);
			StringBuilder sb = new StringBuilder();
			sb.append(String.valueOf(random.nextInt(8999)+1000));
			String cNo1 = sb.toString();
			CreditCard card = new CreditCard(cNo1, cardTypes[choose], "address"+i, random.nextInt(999)+100, expDate, "c"+i,i);
			myDao.saveCreditCard(card);
			sb.append(String.valueOf(random.nextInt(8999)+1000));
			sb.append(String.valueOf(random.nextInt(8999)+1000));
			sb.append(String.valueOf(random.nextInt(8999)+1000));
			String cNo2 = sb.toString();
			myDao.updateCard(cNo2,cNo1);
			//Reservation
			
			Date rDate = new Date(117, 4, i%9+1);
			Date inDate = new Date(117, 5, i/49+2);
			Date outDate = new Date(117,5,i/49+3);
			Date date = new Date(System.currentTimeMillis()-random.nextInt(60)*1000*60*60);
			List<String> btype = new ArrayList<>();
			btype.add(btypes[random.nextInt(5)]);
			List<String> stype = new ArrayList<>();
			stype.add(stypes[random.nextInt(4)]);
			List<Integer> bamount = new ArrayList<>();
			bamount.add(1);
			RoomReservation r1 = new RoomReservation("", i%199+1, i%9+1, inDate, outDate, rtypes[random.nextInt(4)], btype, stype,bamount);
			List<RoomReservation> list = new ArrayList<>();
			list.add(r1);
			long amount = myService.evaluatePrice(r1);
			myService.pay(list, (int) amount, "customer"+i, cNo2);
			Date rdDate = new Date(116, 5, i/49+2);
			//RoomReview
			RoomReview roomReview = new RoomReview(1+(random.nextInt(10)), "roomreview", i, i%199+1, i%9+1,date);
			myDao.saveRoomReview(roomReview);
			//ServiceReview
			ServiceReview serviceReview = new ServiceReview(i%199+1, stypes[random.nextInt(4)], i, 1+(random.nextInt(10)), "service review",date);
			myDao.saveServiceReview(serviceReview);
			//BreakfastReview
			BreakfastReview breakfastReview = new BreakfastReview(i%199+1, btypes[random.nextInt(5)], i, "breakfast review", 1+(random.nextInt(10)),date);
			myDao.saveBreakfastReview(breakfastReview);
		}
		System.out.println("Population Finished");
	}
}
