package team.hr.manager.action;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.service.MyService;

/**
 * Servlet implementation class GetBestServiceType
 */
@WebServlet("/GetBestServiceType")
public class GetBestServiceType extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetBestServiceType() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		MyService myService = new MyService();
		List<String> result = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date start = null;
		Date end = null;
		try {
			start = new Date(sdf.parse(request.getParameter("start")).getTime());
			end = new Date(sdf.parse(request.getParameter("end")).getTime()+60*60*24*1000);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//result.add(myService.bestService(start,end));
		String r = myService.bestService(start,end);
		if(r.equals("")){
			result.add("No service review during selected time");
		}
		else result.add(r);
		request.setAttribute("result", result);
		request.getRequestDispatcher("/WEB-INF/MyPage/result.jsp").forward(request, response);
	}

}
