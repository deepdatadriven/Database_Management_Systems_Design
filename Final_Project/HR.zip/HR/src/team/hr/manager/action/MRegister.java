package team.hr.manager.action;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.Manager;
import team.hr.service.MyService;

/**
 * Servlet implementation class Register
 */
@WebServlet("/MRegister")
public class MRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		if(request.getParameter("login")!=null){
			response.sendRedirect("manager_login.jsp");
			return;
		}
		String name=request.getParameter("name");
		String password = request.getParameter("password");
		String recommendation = request.getParameter("recommendation");
		MyService myService = new MyService();
		String page = "manager_login.jsp";		
		if(!myService.mregister(new Manager(name, password, recommendation))){
			request.setAttribute("userError", name+" already exist");
			page = "mregister.jsp";
		}
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
	}
    

}
