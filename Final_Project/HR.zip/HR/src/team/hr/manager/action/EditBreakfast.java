package team.hr.manager.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.Breakfast;
import team.hr.service.MyService;

/**
 * Servlet implementation class EditBreakfast
 */
@WebServlet("/EditBreakfast")
public class EditBreakfast extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditBreakfast() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		MyService myService = new MyService();
		Integer hotelId = Integer.parseInt(request.getParameter("hotelId"));
		String type = request.getParameter("bType");
		Integer price = Integer.parseInt(request.getParameter("bPrice"));
		String description = request.getParameter("description");
		myService.updateBreakfast(new Breakfast(hotelId, type, price, description));
		request.setAttribute("info", "Edit Breakfast Type Successfully");
		request.getRequestDispatcher("/WEB-INF/MyPage/alter_breakfast.jsp").forward(request, response);
	}

}
