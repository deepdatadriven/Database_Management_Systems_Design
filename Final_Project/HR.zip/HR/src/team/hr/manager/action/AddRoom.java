package team.hr.manager.action;

import java.io.IOException;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.hr.domain.DiscountRoom;
import team.hr.domain.Room;
import team.hr.service.MyService;

/**
 * Servlet implementation class AddRoom
 */
@WebServlet("/AddRoom")
public class AddRoom extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddRoom() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		Integer hotelId = Integer.parseInt(request.getParameter("hotelId"));
		Integer roomNo = Integer.parseInt(request.getParameter("roomNo"));
		String rtype = request.getParameter("rtype");
		Integer price = Integer.parseInt(request.getParameter("price"));
		Integer floor = Integer.parseInt(request.getParameter("floor"));
		Integer capacity = Integer.parseInt(request.getParameter("capacity"));
		String d = request.getParameter("discount");
		String s = request.getParameter("start");
		String e = request.getParameter("end");
		String description = request.getParameter("description");
		
		MyService myService = new MyService();
		myService.saveRoom(new Room(hotelId, roomNo, rtype, price, floor,capacity,description));
		try{
			if(d!=null&&!d.equals("")){
				Double discount = Double.parseDouble(d);
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date start = new Date(sdf.parse(s).getTime());
				Date end = new Date(sdf.parse(e).getTime());
				myService.saveDiscountRoom(new DiscountRoom(hotelId, roomNo, discount, start, end));
			}
		}
		catch(Exception e1){
			e1.printStackTrace();
		}
		request.setAttribute("info", "Add New Room Successfully");
		request.getRequestDispatcher("/WEB-INF/MyPage/add_new_room.jsp").forward(request, response);
	}
}
