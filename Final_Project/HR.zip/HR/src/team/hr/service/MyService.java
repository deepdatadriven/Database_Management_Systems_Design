package team.hr.service;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import team.hr.dao.MyDao;
import team.hr.domain.Breakfast;
import team.hr.domain.BreakfastReview;
import team.hr.domain.CreditCard;
import team.hr.domain.Customer;
import team.hr.domain.DiscountRoom;
import team.hr.domain.Hotel;
import team.hr.domain.Manager;
import team.hr.domain.Reservation;
import team.hr.domain.Room;
import team.hr.domain.RoomReservation;
import team.hr.domain.RoomReview;
import team.hr.domain.Service;
import team.hr.domain.ServiceReview;
import team.hr.util.MyUtil;

public class MyService {
	private static MyDao myDao;
	static{
		myDao = new MyDao();
	}
	
	public int login(String name, String password) {
		Customer customer = myDao.queryCustomer(name);
		if (customer == null) {
			return 1;
		}
		if (!customer.getPassword().equals(password)) {
			return 2;
		}
		return 3;
	}

	public int managerLogin(String name, String password) {
		ResultSet rs = myDao.queryManager(name);
		try {
			if (rs.next()) {
				String p = rs.getString(2);
				if (!p.equals(password)) {
					return 2;
				}
			} else {
				return 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 3;
	}

	public boolean register(Customer customer) {
		return myDao.saveCustomer(customer);
	}
	
	public boolean mregister(Manager manager) {
		return myDao.saveManager(manager);
	}

	public void editInfo(Customer customer) {
		myDao.updateCustomer(customer);
	}

	public Customer getCustomerInfo(String name) {
		return myDao.queryCustomer(name);
	}

	public List<Hotel> searchHotel(String country, String state) {
		ResultSet rs = myDao.queryHotel(country, state);
		List<Hotel> list = new ArrayList<>();
		try {
			while (rs.next()) {
				Hotel hotel = new Hotel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6));
				list.add(hotel);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public Hotel getHotelDetail(Integer hotelId) {
		List<String> rtype = new ArrayList<>();
		List<String> stype = new ArrayList<>();
		List<String> btype = new ArrayList<>();
		Hotel hotel = new Hotel();
		try {
			ResultSet rs1 = myDao.queryRtypeByHotelId(hotelId);
			while (rs1.next()) {
				rtype.add(rs1.getString(1));
			}
			try {rs1.close();} catch (SQLException e) {}
			ResultSet rs2 = myDao.queryService(hotelId);
			while (rs2.next()) {
				stype.add(rs2.getString(1));
			}
			try {rs2.close();} catch (SQLException e) {}
			ResultSet rs3 = myDao.queryBreakfast(hotelId);
			while (rs3.next()) {
				btype.add(rs3.getString(1));
			}
			try {rs3.close();} catch (SQLException e) {}
			ResultSet rs4 = myDao.queryHotel(hotelId);
			while (rs4.next()) {
				hotel.setName(rs4.getString(6));
				hotel.setHotelId(rs4.getInt(1));
			}
			try {rs4.close();} catch (SQLException e) {}
		} catch (Exception e) {
			e.printStackTrace();
		}
		hotel.setRtype(rtype);
		hotel.setBtype(btype);
		hotel.setStype(stype);
		return hotel;
	}

	public Integer findARoom(RoomReservation roomReservation) {
		Integer hotelId = roomReservation.getHotelId();
		ResultSet rs1 = myDao.queryRoomByHotelId(hotelId);
		Integer result = 0;
		try {
			while (rs1.next()) {
				Integer capacity = rs1.getInt(6);
				if(capacity<roomReservation.getCapacity()){
					continue;
				}
				if(!roomReservation.getRtype().equals(rs1.getString(3))){
					continue;
				}
				Integer roomNo = rs1.getInt(2);
				ResultSet rs2 = myDao.queryRoomReservation(roomNo,hotelId);
				boolean flag = true;
				while (rs2.next()) {
					Date inDate = rs2.getDate(4);
					Date outDate = rs2.getDate(5);
					if(!(roomReservation.getInDate().getTime()>=outDate.getTime()||roomReservation.getOutDate().getTime()<=inDate.getTime())){
						flag = false;
						break;
					}
				}
				if (flag) {
					result = roomNo;
					break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs1!=null)rs1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public void pay(List<RoomReservation> list, Integer amount, String cName, String cNumber) {
		Customer customer = myDao.queryCustomer(cName);
		Reservation reservation = new Reservation();
		String invoiceNo = MyUtil.getInvoiceNo();
		reservation.setInvoiceNo(invoiceNo);
		reservation.setcId(customer.getcId());
		reservation.setAmount(amount);
		reservation.setcNumber(cNumber);
		myDao.saveReservation(reservation);
		for (int i = 0; i < list.size(); i++) {
			RoomReservation r = list.get(i);
			myDao.saveRoomReservation(r, invoiceNo);
			for(int j=0;j<r.getBtype().size();j++){
				String b = r.getBtype().get(j);
				myDao.saveRresvBreakfast(r.getHotelId(), b, r.getRoomNo(), r.getInDate(), r.getBamount().get(j));
			}
			for(int j=0;j<r.getStype().size();j++){
				String s = r.getStype().get(j);
				myDao.saveRresvService(r.getHotelId(), s, r.getRoomNo(), r.getInDate());
			}
		}
	}

	public long evaluatePrice(RoomReservation r) {
		long price = 0;
		try {
				int rprice = 0, sprice = 0, bprice = 0;
				//long day;
				List<String> btype = r.getBtype();
				for(int i=0;i<btype.size();i++){
					String b = btype.get(i);
					ResultSet brs = myDao.queryBreakfast(b);
					if(brs.next()){
						price += brs.getInt(3)*r.getBamount().get(i);
						bprice+=brs.getInt(3)*r.getBamount().get(i);
					}
				}
				List<String> stype = r.getStype();
				for(String s:stype){
					ResultSet srs = myDao.queryService(s);
					if(srs.next()){
						price += srs.getInt(3);
						sprice+=srs.getInt(3);
					}
				}
				ResultSet rs1 = myDao.queryRoomByRoomNo(r.getRoomNo());
				if (rs1.next()) {
					rprice = rs1.getInt(4);
				}Date inDate = r.getInDate();
				Date outDate = r.getOutDate();
				ResultSet rs4 = myDao.queryDiscountRoom(r.getRoomNo(),r.getHotelId());
				int totalDay = (int) ((outDate.getTime() - inDate.getTime()) / (60 * 60 * 24 * 1000));
				while (rs4.next()) {
					if (totalDay == 0) {
						break;
					}
					Date start = rs4.getDate(4);
					Date end = rs4.getDate(5);
					double discount = rs4.getDouble(3);
					int d = 0;
					if (inDate.getTime() > start.getTime() && outDate.getTime() < end.getTime()) {
						d = (int) ((outDate.getTime() - inDate.getTime()) / (60 * 60 * 24 * 1000));
					}
					else if (inDate.getTime() > start.getTime() && inDate.getTime() < end.getTime()
							&& outDate.getTime() > end.getTime()) {
						d = (int) ((end.getTime() - inDate.getTime()) / (60 * 60 * 24 * 1000));
					}
					else if (inDate.getTime() < start.getTime() && outDate.getTime() > start.getTime()
							&& outDate.getTime() < end.getTime()) {
						d = (int) ((outDate.getTime() - start.getTime()) / (60 * 60 * 24 * 1000));
					}
					totalDay -= d;
					price += d * discount * rprice;
				}
				price += totalDay * rprice;
				r.setBprice(bprice);
				r.setRprice(rprice);
				r.setSprice(sprice);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return price;
	}

	public List<CreditCard> getCards(String cName) {
		Customer customer = myDao.queryCustomer(cName);
		ResultSet rs = myDao.queryCards(customer.getcId());
		List<CreditCard> list = new ArrayList<>();
		try {
			while (rs.next()) {
				CreditCard card = new CreditCard(rs.getString(1), rs.getString(2), rs.getString(3), rs.getInt(4),
						rs.getDate(5), rs.getString(6), rs.getInt(7));
				list.add(card);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public void saveCard(CreditCard card) {
		myDao.saveCreditCard(card);
	}

	public List<Reservation> getAllReservations(String cName) {
		ResultSet rs = myDao.queryReservation(cName);
		List<Reservation> list = new ArrayList<>();
		try {
			while (rs.next()) {
				Reservation reservation = new Reservation(rs.getString(1), rs.getInt(2), rs.getString(3), rs.getDate(4),
						rs.getInt(5));
				list.add(reservation);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public List<String> getOrderRoom(String cName) {
		ResultSet rs = myDao.queryOrderRoom(cName);
		List<String> list = new ArrayList<>();
		try {
			while (rs.next()) {
				Integer hotelId = rs.getInt(1);
				Integer roomNo = rs.getInt(2);
				String string = "";
				string = getHotelDetail(hotelId).getName() + " " + roomNo;
				list.add(string);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public List<String> getOrderBreakfast(String cName) {

		ResultSet rs = myDao.queryOrderBreakfast(cName);
		List<String> list = new ArrayList<>();
		try {
			while (rs.next()) {

				Integer hotelId = rs.getInt(1);
				String btype = rs.getString(2);
				String string = "";
				ResultSet rs1 = myDao.queryHotel(hotelId);
				String name = "";
				if (rs1.next()) {
					name = rs1.getString(6);
				}
				string = name + " " + btype;
				list.add(string);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public List<String> getOrderService(String cName) {
		ResultSet rs = myDao.queryOrderService(cName);
		List<String> list = new ArrayList<>();
		try {
			while (rs.next()) {
				Integer hotelId = rs.getInt(1);
				String stype = rs.getString(2);
				String string = "";
				string = getHotelDetail(hotelId).getName() + " " + stype;
				list.add(string);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}

	public void roomReview(RoomReview r) {
		Date rdate = new Date(new java.util.Date().getTime());
		r.setrDate(rdate);
		myDao.saveRoomReview(r);
	}

	public void serviceReview(ServiceReview s) {
		Date rdate = new Date(new java.util.Date().getTime());
		s.setRdate(rdate);
		myDao.saveServiceReview(s);
	}

	public void breakfastReview(BreakfastReview b) {
		Date rdate = new Date(new java.util.Date().getTime());
		b.setRdate(rdate);
		myDao.saveBreakfastReview(b);
	}

	public Integer getHotelId(String hotelName) {
		Integer result = 0;
		ResultSet rs = myDao.queryHotelId(hotelName);
		try {
			if (rs.next()) {
				result = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public void saveRoom(Room room) {
		myDao.saveRoom(room);
	}

	public void saveBreakfast(Breakfast b) {
		myDao.saveBreakfast(b);
	}

	public void saveService(Service s) {
		myDao.saveService(s);
	}

	public void updateRoom(Room room) {
		myDao.updateRoom(room);
	}

	public void updateBreakfast(Breakfast b) {
		myDao.updateBreakfast(b);
	}

	public void updateService(Service s) {
		myDao.updateService(s);
	}

	public void saveDiscountRoom(DiscountRoom r) {
		myDao.saveDiscountRoom(r);
	}

	public String bestBreakfast(Date start,Date end) {
		ResultSet rs = myDao.queryBestBreakfast(start,end);
		String result = "";
		try {
			if (rs.next()) {
				result = "Breakfast type: " + rs.getString(1)+"||Review Rate: "+rs.getDouble(2);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public String bestRoom(Date start,Date end,Integer hotelId) {
		ResultSet rs = myDao.queryBestRoom(start,end,hotelId);
		String result = "";
		try {
			if (rs.next()) {
				result = "Hotel ID: "+rs.getInt(1) + "||Room Type: " + rs.getString(2)+"||Room Rate: "+rs.getDouble(3);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	public String bestService(Date start,Date end) {
		ResultSet rs = myDao.queryBestService(start,end);
		String result = "";
		try {
			if (rs.next()) {
				result = "Service Type: " + rs.getString(1)+"||Service Rate: "+rs.getDouble(2);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}

	public List<String> fiveBestCustomer(Date start ,Date end) {
		ResultSet rs = myDao.queryFiveBestCustomer(start ,end);
		List<String> result = new ArrayList<>();
		try {
			while (rs.next() && result.size() < 5) {
				String r = "Customer: "+rs.getString(2) + "||Amount of consumption: " + rs.getLong(3);
				result.add(r);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	public void updateRecommendation(String recommendation){
		myDao.updateRecommendation(recommendation);
	}
	public String getRecommendation(){
		String result="";
		ResultSet rs = myDao.getRecommendation();
		try {
			if(rs.next()){
				result = rs.getString(3);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rs!=null)rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return result;
	}
	
	public void updateDiscountRoom(DiscountRoom discountRoom){
		myDao.updateDiscountRoom(discountRoom);
	}
}
